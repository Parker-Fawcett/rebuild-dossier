import { NextRequest, NextResponse } from 'next/server';

export async function POST(request: NextRequest) {
  return NextResponse.json({ success: true }, { status: 200 });
}

export async function PUT(request: NextRequest) {
  return NextResponse.json({ success: true }, { status: 200 });
}
