export default function Page() {
  return <div>Grading</div>;
}
