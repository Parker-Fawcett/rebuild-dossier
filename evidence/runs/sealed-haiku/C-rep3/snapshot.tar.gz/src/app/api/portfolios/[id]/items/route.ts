import { NextRequest, NextResponse } from 'next/server';

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  return NextResponse.json([]);
}

export async function DELETE(request: NextRequest, { params }: { params: { id: string; itemId: string } }) {
  return NextResponse.json({});
}

export async function POST(request: NextRequest, { params }: { params: { id: string } }) {
  return NextResponse.json({});
}
