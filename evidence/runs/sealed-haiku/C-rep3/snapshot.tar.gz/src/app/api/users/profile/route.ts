import { NextRequest, NextResponse } from 'next/server';

export async function PUT(request: NextRequest) {
  return NextResponse.json({});
}

export async function GET(request: NextRequest) {
  return NextResponse.json({});
}
