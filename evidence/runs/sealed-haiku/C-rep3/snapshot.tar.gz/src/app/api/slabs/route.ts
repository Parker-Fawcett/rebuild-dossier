import { NextResponse } from 'next/server';

export async function GET() { return NextResponse.json([]); }

export async function POST() { return NextResponse.json({ error: 'Slabs feature not yet available' }, { status: 501 }); }

export async function DELETE() { return NextResponse.json({ error: 'Slabs feature not yet available' }, { status: 501 }); }
