export default function Page() {
  return <div>Pokedex ID</div>;
}
