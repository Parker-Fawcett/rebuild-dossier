export default function Page() {
  return <div>Collection Code</div>;
}
