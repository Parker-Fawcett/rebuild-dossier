export default function Page() {
  return <div>Pokedex Collection</div>;
}
