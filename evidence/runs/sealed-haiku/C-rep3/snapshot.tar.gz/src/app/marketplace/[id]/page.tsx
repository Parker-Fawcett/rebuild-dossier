export default function Page() {
  return <div>Marketplace ID</div>;
}
