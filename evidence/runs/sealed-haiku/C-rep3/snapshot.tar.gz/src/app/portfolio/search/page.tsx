export default function Page() {
  return <div>Portfolio Search</div>;
}
