export default function Page() {
  return <div>Callback</div>;
}
