import { NextRequest, NextResponse } from 'next/server';

export async function GET(request: NextRequest) {
  return NextResponse.json({ ok: true });
}

export async function DELETE(request: NextRequest) {
  return NextResponse.json({ ok: true });
}
