import { NextRequest, NextResponse } from 'next/server';

export async function GET(request: NextRequest) {
  return NextResponse.json({ message: 'ok' });
}

export async function DELETE(request: NextRequest) {
  return NextResponse.json({ message: 'ok' });
}
