import { NextRequest, NextResponse } from 'next/server';

export async function POST(request: NextRequest) {
  return NextResponse.json({ message: 'OK' }, { status: 200 });
}

export async function PUT(request: NextRequest) {
  return NextResponse.json({ message: 'OK' }, { status: 200 });
}
