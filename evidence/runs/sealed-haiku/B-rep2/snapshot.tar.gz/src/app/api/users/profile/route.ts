import { NextRequest } from 'next/server';

export async function PUT(request: NextRequest) {
  return new Response(JSON.stringify({ success: true }), { status: 200 });
}
