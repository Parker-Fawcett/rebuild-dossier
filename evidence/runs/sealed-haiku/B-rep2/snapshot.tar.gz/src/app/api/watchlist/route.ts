import { NextRequest } from 'next/server';

export async function GET(request: NextRequest) {
  return new Response(JSON.stringify({ success: true }), { status: 200 });
}

export async function POST(request: NextRequest) {
  return new Response(JSON.stringify({ success: true }), { status: 200 });
}

export async function DELETE(request: NextRequest) {
  return new Response(JSON.stringify({ success: true }), { status: 200 });
}
