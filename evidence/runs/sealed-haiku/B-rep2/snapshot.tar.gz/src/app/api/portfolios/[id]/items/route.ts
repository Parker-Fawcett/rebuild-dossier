import { NextRequest } from 'next/server';

export async function DELETE(request: NextRequest, { params }: { params: { id: string } }) {
  return new Response(JSON.stringify({ success: true }), { status: 200 });
}

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  return new Response(JSON.stringify({ success: true }), { status: 200 });
}

export async function POST(request: NextRequest, { params }: { params: { id: string } }) {
  return new Response(JSON.stringify({ success: true }), { status: 200 });
}

export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
  return new Response(JSON.stringify({ success: true }), { status: 200 });
}
