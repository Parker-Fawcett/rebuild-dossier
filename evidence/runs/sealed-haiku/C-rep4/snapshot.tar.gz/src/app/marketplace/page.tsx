export default function MarketplacePage() {
  return <div>Page</div>;
}
