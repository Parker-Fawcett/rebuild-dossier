export default function CardDetailPage({ params }: { params: { id: string } }) {
  return <div>Page</div>;
}
