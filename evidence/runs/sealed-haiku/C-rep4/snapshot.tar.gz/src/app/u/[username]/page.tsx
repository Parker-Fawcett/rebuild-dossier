export default function PublicProfilePage() {
  return <div>Page</div>;
}
