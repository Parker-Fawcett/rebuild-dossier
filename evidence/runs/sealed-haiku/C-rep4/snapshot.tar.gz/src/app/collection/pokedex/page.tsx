export default function PokedexPage() {
  return <div>Page</div>;
}
