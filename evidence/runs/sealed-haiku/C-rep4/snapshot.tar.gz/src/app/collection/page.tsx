export default function CollectionPage() {
  return <div>Page</div>;
}
