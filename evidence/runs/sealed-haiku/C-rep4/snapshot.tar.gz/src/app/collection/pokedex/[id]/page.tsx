export default function PokemonDetailPage() {
  return <div>Page</div>;
}
