export default function CollectionDetailPage({ params }: { params: { code: string } }) {
  return <div>Page</div>;
}
