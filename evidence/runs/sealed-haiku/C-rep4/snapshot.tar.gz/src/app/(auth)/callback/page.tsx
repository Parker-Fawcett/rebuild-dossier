export default function AuthCallback() {
  return <div>Page</div>;
}
