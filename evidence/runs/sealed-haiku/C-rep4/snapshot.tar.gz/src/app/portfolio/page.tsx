export default function PortfolioPage() {
  return <div>Page</div>;
}
