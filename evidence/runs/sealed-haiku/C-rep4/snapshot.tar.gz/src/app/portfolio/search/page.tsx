export default function PortfolioSearchPage() {
  return <div>Page</div>;
}
