export default function OnboardingPage() {
  return <div>Page</div>;
}
