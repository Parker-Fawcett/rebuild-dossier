export default function GradingPage() {
  return <div>Page</div>;
}
