export default function WatchlistPage() {
  return <div>Page</div>;
}
