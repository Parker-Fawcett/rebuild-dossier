export default function ScanPage() {
  return <div>Page</div>;
}
