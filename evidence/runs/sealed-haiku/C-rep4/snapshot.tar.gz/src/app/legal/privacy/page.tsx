export default function PrivacyPolicy() {
  return <div>Page</div>;
}
