export default function TermsOfService() {
  return <div>Page</div>;
}
