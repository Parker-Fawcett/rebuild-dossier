import { NextRequest, NextResponse } from 'next/server';

export async function GET(request: NextRequest, { params }: { params: { id: string; itemId: string } }) {
  return NextResponse.json({ item: {} }, { status: 200 });
}

export async function DELETE(request: NextRequest, { params }: { params: { id: string; itemId: string } }) {
  return NextResponse.json({ success: true }, { status: 200 });
}
