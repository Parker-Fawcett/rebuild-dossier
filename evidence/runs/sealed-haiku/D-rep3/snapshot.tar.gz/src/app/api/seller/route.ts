import { NextRequest, NextResponse } from 'next/server';

export async function GET(request: NextRequest) {
  return NextResponse.json({ seller: null });
}

export async function PUT(request: NextRequest) {
  return NextResponse.json({ ok: true });
}
