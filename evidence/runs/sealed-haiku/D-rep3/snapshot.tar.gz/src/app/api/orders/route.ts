import { NextRequest, NextResponse } from 'next/server';

export async function GET(request: NextRequest) {
  return NextResponse.json({ orders: [] });
}

export async function POST(request: NextRequest) {
  return NextResponse.json({ id: 'new-order' });
}

export async function PUT(request: NextRequest) {
  return NextResponse.json({ ok: true });
}
