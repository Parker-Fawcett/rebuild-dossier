import { NextRequest, NextResponse } from 'next/server';

export async function POST(request: NextRequest) {
  return NextResponse.json({ id: 'new-portfolio' });
}

export async function GET(request: NextRequest) {
  return NextResponse.json({ portfolios: [] });
}
