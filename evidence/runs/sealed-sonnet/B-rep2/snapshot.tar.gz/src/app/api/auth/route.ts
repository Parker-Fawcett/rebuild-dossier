import { NextRequest, NextResponse } from 'next/server';

export async function POST(request: NextRequest) {
  let body: Record<string, unknown> = {};
  try {
    body = await request.json();
  } catch {
    body = {};
  }

  if (!body.email || !body.password) {
    return NextResponse.json({ error: 'Missing credentials' }, { status: 400 });
  }

  return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
}
