import { NextRequest, NextResponse } from 'next/server';

export async function POST(request: NextRequest) {
  let body: Record<string, unknown> = {};
  try {
    body = await request.json();
  } catch {
    body = {};
  }

  return NextResponse.json({ id: crypto.randomUUID(), ...body }, { status: 201 });
}
