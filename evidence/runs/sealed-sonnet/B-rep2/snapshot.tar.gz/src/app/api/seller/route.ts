import { NextRequest, NextResponse } from 'next/server';

export async function PUT(request: NextRequest) {
  let body: Record<string, unknown> = {};
  try {
    body = await request.json();
  } catch {
    body = {};
  }

  return NextResponse.json({ ...body });
}
