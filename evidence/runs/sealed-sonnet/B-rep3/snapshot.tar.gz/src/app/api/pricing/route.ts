import { NextRequest, NextResponse } from 'next/server';

export async function POST(request: NextRequest) {
  let body: any = null;
  try {
    body = await request.json();
  } catch {
    body = null;
  }

  if (!body || !body.cardId) {
    return NextResponse.json({ error: 'Missing cardId' }, { status: 400 });
  }

  return NextResponse.json({ error: 'Not found' }, { status: 404 });
}
