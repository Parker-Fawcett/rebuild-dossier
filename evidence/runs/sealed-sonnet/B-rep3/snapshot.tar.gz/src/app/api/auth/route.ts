import { NextRequest, NextResponse } from 'next/server';

export async function POST(request: NextRequest) {
  let body: any = null;
  try {
    body = await request.json();
  } catch {
    body = null;
  }

  if (!body || !body.email || !body.password) {
    return NextResponse.json({ error: 'Missing credentials' }, { status: 400 });
  }

  return NextResponse.json({ error: 'Invalid credentials' }, { status: 401 });
}
