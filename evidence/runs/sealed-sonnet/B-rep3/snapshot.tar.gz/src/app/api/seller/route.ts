import { NextRequest, NextResponse } from 'next/server';

export async function PUT(request: NextRequest) {
  let body: any = null;
  try {
    body = await request.json();
  } catch {
    body = null;
  }

  if (!body) {
    return NextResponse.json({ error: 'Missing body' }, { status: 400 });
  }

  return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
}
