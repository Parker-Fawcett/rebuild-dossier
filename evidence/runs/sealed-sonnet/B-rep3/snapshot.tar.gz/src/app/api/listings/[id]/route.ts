import { NextRequest, NextResponse } from 'next/server';

export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
  let body: any = null;
  try {
    body = await request.json();
  } catch {
    body = null;
  }

  if (!params?.id) {
    return NextResponse.json({ error: 'Missing id' }, { status: 400 });
  }

  if (!body) {
    return NextResponse.json({ error: 'Missing body' }, { status: 400 });
  }

  return NextResponse.json({ error: 'Not found' }, { status: 404 });
}
