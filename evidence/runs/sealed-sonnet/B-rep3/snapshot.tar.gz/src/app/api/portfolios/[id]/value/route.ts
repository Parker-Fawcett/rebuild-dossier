import { NextRequest, NextResponse } from 'next/server';

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  if (!params?.id) {
    return NextResponse.json({ error: 'Missing id' }, { status: 400 });
  }

  return NextResponse.json({ error: 'Not found' }, { status: 404 });
}
