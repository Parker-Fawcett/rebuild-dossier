import { NextRequest, NextResponse } from 'next/server';

export async function POST(request: NextRequest) {
  let body: any = null;
  try {
    body = await request.json();
  } catch {
    body = null;
  }

  if (!body || !body.query) {
    return NextResponse.json({ error: 'Missing query' }, { status: 400 });
  }

  return NextResponse.json({ results: [] });
}
