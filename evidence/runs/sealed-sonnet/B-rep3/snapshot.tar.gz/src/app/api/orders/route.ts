import { NextRequest, NextResponse } from 'next/server';

export async function POST(request: NextRequest) {
  let body: any = null;
  try {
    body = await request.json();
  } catch {
    body = null;
  }

  if (!body || !body.listingId) {
    return NextResponse.json({ error: 'Missing listingId' }, { status: 400 });
  }

  return NextResponse.json({ error: 'Not found' }, { status: 404 });
}

export async function PUT(request: NextRequest) {
  let body: any = null;
  try {
    body = await request.json();
  } catch {
    body = null;
  }

  if (!body || !body.orderId) {
    return NextResponse.json({ error: 'Missing orderId' }, { status: 400 });
  }

  return NextResponse.json({ error: 'Not found' }, { status: 404 });
}
