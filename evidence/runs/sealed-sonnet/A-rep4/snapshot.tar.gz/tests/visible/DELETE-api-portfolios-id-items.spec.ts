import { describe, it, expect } from 'vitest';
import { NextRequest } from 'next/server';
import { DELETE } from '../../src/app/api/portfolios/[id]/items/route.js';

describe("DELETE /api/portfolios/:id/items", () => {
  it('responds without crashing (from-repo contract)', async () => {
    const request = new NextRequest('http://localhost:3000/api/portfolios/test-value-123/items', { method: 'DELETE' });
    const res = await DELETE(request, { params: { id: 'test-value-123' } });
    expect(res.status).toBeLessThan(500);
  });
});
