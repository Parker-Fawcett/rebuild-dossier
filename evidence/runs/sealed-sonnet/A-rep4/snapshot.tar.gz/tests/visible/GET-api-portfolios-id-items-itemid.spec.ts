import { describe, it, expect } from 'vitest';
import { NextRequest } from 'next/server';
import { GET } from '../../src/app/api/portfolios/[id]/items/[itemId]/route.js';

describe("GET /api/portfolios/:id/items/:itemId", () => {
  it('responds without crashing (from-repo contract)', async () => {
    const request = new NextRequest('http://localhost:3000/api/portfolios/test-value-123/items/test-value-123', { method: 'GET' });
    const res = await GET(request, { params: { id: 'test-value-123', itemId: 'test-value-123' } });
    expect(res.status).toBeLessThan(500);
  });
});
