import { describe, it, expect } from 'vitest';
import { NextRequest } from 'next/server';
import { POST } from '../../src/app/api/portfolios/route.js';

describe("POST /api/portfolios", () => {
  it('responds without crashing (from-repo contract)', async () => {
    const request = new NextRequest('http://localhost:3000/api/portfolios', { method: 'POST' });
    const res = await POST(request, { params: {} });
    expect(res.status).toBeLessThan(500);
  });
});
