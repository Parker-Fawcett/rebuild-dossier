import { describe, it, expect } from 'vitest';
import { NextRequest } from 'next/server';
import { GET } from '../../src/app/api/portfolios/[id]/value/route.js';

describe("GET /api/portfolios/:id/value", () => {
  it('responds without crashing (from-repo contract)', async () => {
    const request = new NextRequest('http://localhost:3000/api/portfolios/test-value-123/value', { method: 'GET' });
    const res = await GET(request, { params: { id: 'test-value-123' } });
    expect(res.status).toBeLessThan(500);
  });
});
