import { describe, it, expect } from 'vitest';
import { NextRequest } from 'next/server';
import { PUT } from '../../src/app/api/seller/route.js';

describe("PUT /api/seller", () => {
  it('responds without crashing (from-repo contract)', async () => {
    const request = new NextRequest('http://localhost:3000/api/seller', { method: 'PUT' });
    const res = await PUT(request, { params: {} });
    expect(res.status).toBeLessThan(500);
  });
});
