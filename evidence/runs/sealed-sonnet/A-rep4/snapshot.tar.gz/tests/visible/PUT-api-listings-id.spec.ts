import { describe, it, expect } from 'vitest';
import { NextRequest } from 'next/server';
import { PUT } from '../../src/app/api/listings/[id]/route.js';

describe("PUT /api/listings/:id", () => {
  it('responds without crashing (from-repo contract)', async () => {
    const request = new NextRequest('http://localhost:3000/api/listings/test-value-123', { method: 'PUT' });
    const res = await PUT(request, { params: { id: 'test-value-123' } });
    expect(res.status).toBeLessThan(500);
  });
});
