import { describe, it, expect } from 'vitest';
import { NextRequest } from 'next/server';
import { POST } from '../../src/app/api/orders/route.js';

describe("POST /api/orders", () => {
  it('responds without crashing (from-repo contract)', async () => {
    const request = new NextRequest('http://localhost:3000/api/orders', { method: 'POST' });
    const res = await POST(request, { params: {} });
    expect(res.status).toBeLessThan(500);
  });
});
