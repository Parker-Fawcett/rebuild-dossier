import { describe, it, expect } from 'vitest';
import { NextRequest } from 'next/server';
import { GET } from '../../src/app/api/users/[id]/route.js';

describe("GET /api/users/:id", () => {
  it('responds without crashing (from-repo contract)', async () => {
    const request = new NextRequest('http://localhost:3000/api/users/test-value-123', { method: 'GET' });
    const res = await GET(request, { params: { id: 'test-value-123' } });
    expect(res.status).toBeLessThan(500);
  });
});
