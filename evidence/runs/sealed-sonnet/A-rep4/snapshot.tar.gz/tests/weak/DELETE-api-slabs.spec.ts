import { describe, it, expect } from 'vitest';
import { NextRequest } from 'next/server';
import { DELETE } from '../../src/app/api/slabs/route.js';

describe("DELETE /api/slabs", () => {
  it('responds without crashing (from-repo contract)', async () => {
    const request = new NextRequest('http://localhost:3000/api/slabs', { method: 'DELETE' });
    const res = await DELETE(request, { params: {} });
    expect(res.status).toBeLessThan(500);
  });
});
