import { describe, it, expect } from 'vitest';
import { NextRequest } from 'next/server';
import { GET } from '../../src/app/api/portfolios/user/[userId]/route.js';

describe("GET /api/portfolios/user/:userId", () => {
  it('responds without crashing (from-repo contract)', async () => {
    const request = new NextRequest('http://localhost:3000/api/portfolios/user/test-value-123', { method: 'GET' });
    const res = await GET(request, { params: { userId: 'test-value-123' } });
    expect(res.status).toBeLessThan(500);
  });
});
