import { describe, it, expect } from 'vitest';
import { NextRequest } from 'next/server';
import { GET } from '../../src/app/api/sets/[code]/route.js';

describe("GET /api/sets/:code", () => {
  it('responds without crashing (from-repo contract)', async () => {
    const request = new NextRequest('http://localhost:3000/api/sets/test-value-123', { method: 'GET' });
    const res = await GET(request, { params: { code: 'test-value-123' } });
    expect(res.status).toBeLessThan(500);
  });
});
