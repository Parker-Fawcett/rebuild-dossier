import { describe, it, expect } from 'vitest';
import { NextRequest } from 'next/server';
import { GET } from '../../src/app/api/sets/route.js';

describe("GET /api/sets", () => {
  it('responds without crashing (from-repo contract)', async () => {
    const request = new NextRequest('http://localhost:3000/api/sets', { method: 'GET' });
    const res = await GET(request, { params: {} });
    expect(res.status).toBeLessThan(500);
  });
});
