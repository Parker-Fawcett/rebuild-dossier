import { describe, it, expect } from 'vitest';
import { NextRequest } from 'next/server';
import { DELETE } from '../../src/app/api/users/[id]/route.js';

describe("DELETE /api/users/:id", () => {
  it('responds without crashing (from-repo contract)', async () => {
    const request = new NextRequest('http://localhost:3000/api/users/test-value-123', { method: 'DELETE' });
    const res = await DELETE(request, { params: { id: 'test-value-123' } });
    expect(res.status).toBeLessThan(500);
  });
});
