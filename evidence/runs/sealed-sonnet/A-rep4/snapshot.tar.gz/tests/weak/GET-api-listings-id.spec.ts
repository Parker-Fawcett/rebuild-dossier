import { describe, it, expect } from 'vitest';
import { NextRequest } from 'next/server';
import { GET } from '../../src/app/api/listings/[id]/route.js';

describe("GET /api/listings/:id", () => {
  it('responds without crashing (from-repo contract)', async () => {
    const request = new NextRequest('http://localhost:3000/api/listings/test-value-123', { method: 'GET' });
    const res = await GET(request, { params: { id: 'test-value-123' } });
    expect(res.status).toBeLessThan(500);
  });
});
