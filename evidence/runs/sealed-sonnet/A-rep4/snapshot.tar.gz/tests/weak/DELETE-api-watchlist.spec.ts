import { describe, it, expect } from 'vitest';
import { NextRequest } from 'next/server';
import { DELETE } from '../../src/app/api/watchlist/route.js';

describe("DELETE /api/watchlist", () => {
  it('responds without crashing (from-repo contract)', async () => {
    const request = new NextRequest('http://localhost:3000/api/watchlist', { method: 'DELETE' });
    const res = await DELETE(request, { params: {} });
    expect(res.status).toBeLessThan(500);
  });
});
