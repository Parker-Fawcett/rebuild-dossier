# Contract: POST /api/auth

- **File:** src/app/api/auth/route.ts
- **Kind:** api
- **Line:** 25

## Signature (verbatim from source)

```
export async function POST(request: NextRequest) {
```
