# Contract: /grading

- **File:** src/app/grading/page.tsx
- **Kind:** page
- **Line:** 30

## Signature (verbatim from source)

```
export default function GradingPage() {
```
