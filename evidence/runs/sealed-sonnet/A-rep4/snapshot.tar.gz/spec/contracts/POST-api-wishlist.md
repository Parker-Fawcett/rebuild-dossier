# Contract: POST /api/wishlist

- **File:** src/app/api/wishlist/route.ts
- **Kind:** api
- **Line:** 4

## Signature (verbatim from source)

```
export async function POST() { return NextResponse.json({ error: 'Use /api/watchlist instead' }, { status: 501 }); }
```
