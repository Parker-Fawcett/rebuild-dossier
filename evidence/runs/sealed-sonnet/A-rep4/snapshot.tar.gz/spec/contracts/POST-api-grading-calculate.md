# Contract: POST /api/grading/calculate

- **File:** src/app/api/grading/calculate/route.ts
- **Kind:** api
- **Line:** 12

## Signature (verbatim from source)

```
export async function POST(request: NextRequest) {
```
