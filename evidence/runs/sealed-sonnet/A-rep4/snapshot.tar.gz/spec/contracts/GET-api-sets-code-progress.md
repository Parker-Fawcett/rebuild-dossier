# Contract: GET /api/sets/:code/progress

- **File:** src/app/api/sets/[code]/progress/route.ts
- **Kind:** api
- **Line:** 4

## Signature (verbatim from source)

```
export async function GET(request: NextRequest, { params }: { params: { code: string } }) {
```
