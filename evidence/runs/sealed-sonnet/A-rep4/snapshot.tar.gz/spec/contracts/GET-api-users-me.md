# Contract: GET /api/users/me

- **File:** src/app/api/users/me/route.ts
- **Kind:** api
- **Line:** 4

## Signature (verbatim from source)

```
export async function GET(request: NextRequest) {
```
