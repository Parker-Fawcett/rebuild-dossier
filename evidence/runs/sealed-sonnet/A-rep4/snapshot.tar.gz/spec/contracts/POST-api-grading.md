# Contract: POST /api/grading

- **File:** src/app/api/grading/route.ts
- **Kind:** api
- **Line:** 9

## Signature (verbatim from source)

```
export async function POST(request: NextRequest) {
```
