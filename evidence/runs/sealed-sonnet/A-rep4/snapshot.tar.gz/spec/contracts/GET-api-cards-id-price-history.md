# Contract: GET /api/cards/:id/price-history

- **File:** src/app/api/cards/[id]/price-history/route.ts
- **Kind:** api
- **Line:** 28

## Signature (verbatim from source)

```
export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
```
