# Contract: GET /api/auth/google

- **File:** src/app/api/auth/google/route.ts
- **Kind:** api
- **Line:** 8

## Signature (verbatim from source)

```
export async function GET(request: NextRequest) {
```
