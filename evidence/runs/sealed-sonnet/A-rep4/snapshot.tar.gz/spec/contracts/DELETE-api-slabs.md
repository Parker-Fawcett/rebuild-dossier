# Contract: DELETE /api/slabs

- **File:** src/app/api/slabs/route.ts
- **Kind:** api
- **Line:** 6

## Signature (verbatim from source)

```
export async function DELETE() { return NextResponse.json({ error: 'Slabs feature not yet available' }, { status: 501 }); }
```
