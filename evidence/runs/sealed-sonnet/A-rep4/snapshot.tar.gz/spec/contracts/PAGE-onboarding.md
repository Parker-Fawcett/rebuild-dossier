# Contract: /onboarding

- **File:** src/app/onboarding/page.tsx
- **Kind:** page
- **Line:** 90

## Signature (verbatim from source)

```
export default function OnboardingPage() {
```
