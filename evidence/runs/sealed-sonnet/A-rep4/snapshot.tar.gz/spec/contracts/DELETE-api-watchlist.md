# Contract: DELETE /api/watchlist

- **File:** src/app/api/watchlist/route.ts
- **Kind:** api
- **Line:** 54

## Signature (verbatim from source)

```
export async function DELETE(request: NextRequest) {
```
