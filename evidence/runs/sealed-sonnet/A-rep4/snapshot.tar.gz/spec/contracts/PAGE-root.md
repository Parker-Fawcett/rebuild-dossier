# Contract: /

- **File:** src/app/page.tsx
- **Kind:** page
- **Line:** 1065

## Signature (verbatim from source)

```
export default function HomePage() {
```
