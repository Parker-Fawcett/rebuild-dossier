# Contract: POST /api/users

- **File:** src/app/api/users/route.ts
- **Kind:** api
- **Line:** 45

## Signature (verbatim from source)

```
export async function POST(request: NextRequest) {
```
