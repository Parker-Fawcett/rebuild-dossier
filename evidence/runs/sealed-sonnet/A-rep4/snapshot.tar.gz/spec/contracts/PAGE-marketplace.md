# Contract: /marketplace

- **File:** src/app/marketplace/page.tsx
- **Kind:** page
- **Line:** 84

## Signature (verbatim from source)

```
export default function MarketplacePage() {
```
