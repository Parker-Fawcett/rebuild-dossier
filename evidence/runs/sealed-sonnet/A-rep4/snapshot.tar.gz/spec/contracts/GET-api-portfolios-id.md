# Contract: GET /api/portfolios/:id

- **File:** src/app/api/portfolios/[id]/route.ts
- **Kind:** api
- **Line:** 10

## Signature (verbatim from source)

```
export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
```
