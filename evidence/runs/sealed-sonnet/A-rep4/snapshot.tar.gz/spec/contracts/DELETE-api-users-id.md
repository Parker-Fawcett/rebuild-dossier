# Contract: DELETE /api/users/:id

- **File:** src/app/api/users/[id]/route.ts
- **Kind:** api
- **Line:** 53

## Signature (verbatim from source)

```
export async function DELETE(request: NextRequest, { params }: { params: { id: string } }) {
```
