# Contract: GET /api/ebay

- **File:** src/app/api/ebay/route.ts
- **Kind:** api
- **Line:** 27

## Signature (verbatim from source)

```
export async function GET(request: NextRequest) {
```
