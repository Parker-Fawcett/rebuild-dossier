# Contract: POST /api/pricing

- **File:** src/app/api/pricing/route.ts
- **Kind:** api
- **Line:** 72

## Signature (verbatim from source)

```
export async function POST(request: NextRequest) {
```
