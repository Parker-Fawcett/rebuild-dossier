# Contract: PUT /api/users/:id

- **File:** src/app/api/users/[id]/route.ts
- **Kind:** api
- **Line:** 23

## Signature (verbatim from source)

```
export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
```
