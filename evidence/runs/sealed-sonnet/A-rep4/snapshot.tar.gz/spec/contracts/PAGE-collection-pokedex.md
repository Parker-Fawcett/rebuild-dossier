# Contract: /collection/pokedex

- **File:** src/app/collection/pokedex/page.tsx
- **Kind:** page
- **Line:** 37

## Signature (verbatim from source)

```
export default function PokedexPage() {
```
