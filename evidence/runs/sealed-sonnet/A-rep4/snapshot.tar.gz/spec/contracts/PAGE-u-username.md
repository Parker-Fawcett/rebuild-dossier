# Contract: /u/:username

- **File:** src/app/u/[username]/page.tsx
- **Kind:** page
- **Line:** 77

## Signature (verbatim from source)

```
export default function PublicProfilePage() {
```
