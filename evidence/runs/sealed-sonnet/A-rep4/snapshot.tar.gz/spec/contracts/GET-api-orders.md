# Contract: GET /api/orders

- **File:** src/app/api/orders/route.ts
- **Kind:** api
- **Line:** 10

## Signature (verbatim from source)

```
export async function GET(request: NextRequest) {
```
