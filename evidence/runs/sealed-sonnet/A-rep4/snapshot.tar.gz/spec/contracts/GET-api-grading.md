# Contract: GET /api/grading

- **File:** src/app/api/grading/route.ts
- **Kind:** api
- **Line:** 5

## Signature (verbatim from source)

```
export async function GET(request: NextRequest) {
```
