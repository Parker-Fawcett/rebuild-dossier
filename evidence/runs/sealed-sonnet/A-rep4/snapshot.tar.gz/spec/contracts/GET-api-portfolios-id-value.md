# Contract: GET /api/portfolios/:id/value

- **File:** src/app/api/portfolios/[id]/value/route.ts
- **Kind:** api
- **Line:** 9

## Signature (verbatim from source)

```
export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
```
