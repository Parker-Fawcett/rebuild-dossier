# Contract: GET /api/listings

- **File:** src/app/api/listings/route.ts
- **Kind:** api
- **Line:** 4

## Signature (verbatim from source)

```
export async function GET(request: NextRequest) {
```
