# Contract: GET /api/pokedex/:id

- **File:** src/app/api/pokedex/[id]/route.ts
- **Kind:** api
- **Line:** 4

## Signature (verbatim from source)

```
export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
```
