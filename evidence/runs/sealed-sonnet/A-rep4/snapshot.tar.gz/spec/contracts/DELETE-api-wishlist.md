# Contract: DELETE /api/wishlist

- **File:** src/app/api/wishlist/route.ts
- **Kind:** api
- **Line:** 5

## Signature (verbatim from source)

```
export async function DELETE() { return NextResponse.json({ error: 'Use /api/watchlist instead' }, { status: 501 }); }
```
