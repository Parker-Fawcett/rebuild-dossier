# Contract: PUT /api/seller

- **File:** src/app/api/seller/route.ts
- **Kind:** api
- **Line:** 44

## Signature (verbatim from source)

```
export async function PUT(request: NextRequest) {
```
