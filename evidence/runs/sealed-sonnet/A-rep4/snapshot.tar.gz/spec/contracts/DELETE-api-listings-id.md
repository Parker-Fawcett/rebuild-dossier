# Contract: DELETE /api/listings/:id

- **File:** src/app/api/listings/[id]/route.ts
- **Kind:** api
- **Line:** 54

## Signature (verbatim from source)

```
export async function DELETE(request: NextRequest, { params }: { params: { id: string } }) {
```
