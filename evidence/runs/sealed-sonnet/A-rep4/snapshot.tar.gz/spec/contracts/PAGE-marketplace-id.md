# Contract: /marketplace/:id

- **File:** src/app/marketplace/[id]/page.tsx
- **Kind:** page
- **Line:** 38

## Signature (verbatim from source)

```
export default function CardDetailPage({ params }: { params: { id: string } }) {
```
