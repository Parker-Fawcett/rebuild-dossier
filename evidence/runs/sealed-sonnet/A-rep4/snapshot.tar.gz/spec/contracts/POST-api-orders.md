# Contract: POST /api/orders

- **File:** src/app/api/orders/route.ts
- **Kind:** api
- **Line:** 39

## Signature (verbatim from source)

```
export async function POST(request: NextRequest) {
```
