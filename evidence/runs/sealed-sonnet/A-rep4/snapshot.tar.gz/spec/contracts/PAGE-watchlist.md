# Contract: /watchlist

- **File:** src/app/watchlist/page.tsx
- **Kind:** page
- **Line:** 43

## Signature (verbatim from source)

```
export default function WatchlistPage() {
```
