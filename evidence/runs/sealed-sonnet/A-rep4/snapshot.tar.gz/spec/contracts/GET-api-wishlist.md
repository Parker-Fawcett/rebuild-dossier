# Contract: GET /api/wishlist

- **File:** src/app/api/wishlist/route.ts
- **Kind:** api
- **Line:** 3

## Signature (verbatim from source)

```
export async function GET() { return NextResponse.json([]); }
```
