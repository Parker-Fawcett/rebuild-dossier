# Contract: GET /api/grading/calculate

- **File:** src/app/api/grading/calculate/route.ts
- **Kind:** api
- **Line:** 8

## Signature (verbatim from source)

```
export async function GET(request: NextRequest) {
```
