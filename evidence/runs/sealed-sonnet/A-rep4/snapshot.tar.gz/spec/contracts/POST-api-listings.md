# Contract: POST /api/listings

- **File:** src/app/api/listings/route.ts
- **Kind:** api
- **Line:** 40

## Signature (verbatim from source)

```
export async function POST(request: NextRequest) {
```
