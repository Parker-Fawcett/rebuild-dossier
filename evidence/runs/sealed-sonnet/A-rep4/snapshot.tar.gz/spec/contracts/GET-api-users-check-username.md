# Contract: GET /api/users/check-username

- **File:** src/app/api/users/check-username/route.ts
- **Kind:** api
- **Line:** 4

## Signature (verbatim from source)

```
export async function GET(request: NextRequest) {
```
