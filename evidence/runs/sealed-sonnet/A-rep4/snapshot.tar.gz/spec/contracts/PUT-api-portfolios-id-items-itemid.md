# Contract: PUT /api/portfolios/:id/items/:itemId

- **File:** src/app/api/portfolios/[id]/items/[itemId]/route.ts
- **Kind:** api
- **Line:** 32

## Signature (verbatim from source)

```
export async function PUT(request: NextRequest, { params }: { params: { id: string; itemId: string } }) {
```
