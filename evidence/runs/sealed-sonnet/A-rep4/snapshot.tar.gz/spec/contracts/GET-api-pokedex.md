# Contract: GET /api/pokedex

- **File:** src/app/api/pokedex/route.ts
- **Kind:** api
- **Line:** 9

## Signature (verbatim from source)

```
export async function GET(request: NextRequest) {
```
