# Contract: POST /api/portfolios

- **File:** src/app/api/portfolios/route.ts
- **Kind:** api
- **Line:** 44

## Signature (verbatim from source)

```
export async function POST(request: NextRequest) {
```
