# Contract: PUT /api/listings/:id

- **File:** src/app/api/listings/[id]/route.ts
- **Kind:** api
- **Line:** 28

## Signature (verbatim from source)

```
export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
```
