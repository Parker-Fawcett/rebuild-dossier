# Contract: GET /api/auth

- **File:** src/app/api/auth/route.ts
- **Kind:** api
- **Line:** 5

## Signature (verbatim from source)

```
export async function GET(request: NextRequest) {
```
