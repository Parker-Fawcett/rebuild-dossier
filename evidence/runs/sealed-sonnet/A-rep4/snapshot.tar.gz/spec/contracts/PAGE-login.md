# Contract: /login

- **File:** src/app/(auth)/login/page.tsx
- **Kind:** page
- **Line:** 54

## Signature (verbatim from source)

```
export default function LoginPage() {
```
