# Contract: PUT /api/orders

- **File:** src/app/api/orders/route.ts
- **Kind:** api
- **Line:** 76

## Signature (verbatim from source)

```
export async function PUT(request: NextRequest) {
```
