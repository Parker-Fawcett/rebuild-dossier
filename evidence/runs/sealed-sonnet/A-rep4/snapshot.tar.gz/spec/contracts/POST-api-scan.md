# Contract: POST /api/scan

- **File:** src/app/api/scan/route.ts
- **Kind:** api
- **Line:** 14

## Signature (verbatim from source)

```
export async function POST(request: NextRequest) {
```
