# Contract: GET /api/users/:id

- **File:** src/app/api/users/[id]/route.ts
- **Kind:** api
- **Line:** 5

## Signature (verbatim from source)

```
export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
```
