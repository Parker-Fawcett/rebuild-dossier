# Contract: /portfolio/search

- **File:** src/app/portfolio/search/page.tsx
- **Kind:** page
- **Line:** 465

## Signature (verbatim from source)

```
export default function PortfolioSearchPage() {
```
