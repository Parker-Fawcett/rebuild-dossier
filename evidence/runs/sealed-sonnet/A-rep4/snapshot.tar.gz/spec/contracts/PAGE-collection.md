# Contract: /collection

- **File:** src/app/collection/page.tsx
- **Kind:** page
- **Line:** 36

## Signature (verbatim from source)

```
export default function CollectionPage() {
```
