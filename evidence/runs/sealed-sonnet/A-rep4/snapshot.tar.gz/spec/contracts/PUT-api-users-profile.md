# Contract: PUT /api/users/profile

- **File:** src/app/api/users/profile/route.ts
- **Kind:** api
- **Line:** 4

## Signature (verbatim from source)

```
export async function PUT(request: NextRequest) {
```
