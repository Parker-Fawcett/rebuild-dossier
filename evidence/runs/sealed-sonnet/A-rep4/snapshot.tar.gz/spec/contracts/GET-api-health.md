# Contract: GET /api/health

- **File:** src/app/api/health/route.ts
- **Kind:** api
- **Line:** 5

## Signature (verbatim from source)

```
export async function GET() {
```
