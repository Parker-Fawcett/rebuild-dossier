# Contract: /collection/:code

- **File:** src/app/collection/[code]/page.tsx
- **Kind:** page
- **Line:** 105

## Signature (verbatim from source)

```
export default function CollectionDetailPage({ params }: { params: { code: string } }) {
```
