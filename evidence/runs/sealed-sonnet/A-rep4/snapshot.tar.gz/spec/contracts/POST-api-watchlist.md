# Contract: POST /api/watchlist

- **File:** src/app/api/watchlist/route.ts
- **Kind:** api
- **Line:** 28

## Signature (verbatim from source)

```
export async function POST(request: NextRequest) {
```
