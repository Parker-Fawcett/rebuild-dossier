# Contract: GET /api/portfolios/user/:userId

- **File:** src/app/api/portfolios/user/[userId]/route.ts
- **Kind:** api
- **Line:** 4

## Signature (verbatim from source)

```
export async function GET(request: NextRequest, { params }: { params: { userId: string } }) {
```
