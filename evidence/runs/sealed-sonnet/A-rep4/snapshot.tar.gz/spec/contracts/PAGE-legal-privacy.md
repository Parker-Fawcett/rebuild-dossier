# Contract: /legal/privacy

- **File:** src/app/legal/privacy/page.tsx
- **Kind:** page
- **Line:** 5

## Signature (verbatim from source)

```
export default function PrivacyPolicy() {
```
