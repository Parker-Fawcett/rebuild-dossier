# Contract: GET /api/watchlist

- **File:** src/app/api/watchlist/route.ts
- **Kind:** api
- **Line:** 10

## Signature (verbatim from source)

```
export async function GET(request: NextRequest) {
```
