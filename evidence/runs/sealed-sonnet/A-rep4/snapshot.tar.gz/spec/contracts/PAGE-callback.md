# Contract: /callback

- **File:** src/app/(auth)/callback/page.tsx
- **Kind:** page
- **Line:** 10

## Signature (verbatim from source)

```
export default function AuthCallback() {
```
