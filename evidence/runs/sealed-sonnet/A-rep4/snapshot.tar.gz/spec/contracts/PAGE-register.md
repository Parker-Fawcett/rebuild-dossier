# Contract: /register

- **File:** src/app/(auth)/register/page.tsx
- **Kind:** page
- **Line:** 52

## Signature (verbatim from source)

```
export default function RegisterPage() {
```
