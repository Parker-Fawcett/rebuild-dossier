# Contract: POST /api/auth/login

- **File:** src/app/api/auth/login/route.ts
- **Kind:** api
- **Line:** 6

## Signature (verbatim from source)

```
export async function POST(request: NextRequest) {
```
