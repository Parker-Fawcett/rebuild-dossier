# Contract: GET /api/slabs

- **File:** src/app/api/slabs/route.ts
- **Kind:** api
- **Line:** 4

## Signature (verbatim from source)

```
export async function GET() { return NextResponse.json([]); }
```
