# Contract: GET /api/portfolios/:id/items/:itemId

- **File:** src/app/api/portfolios/[id]/items/[itemId]/route.ts
- **Kind:** api
- **Line:** 9

## Signature (verbatim from source)

```
export async function GET(request: NextRequest, { params }: { params: { id: string; itemId: string } }) {
```
