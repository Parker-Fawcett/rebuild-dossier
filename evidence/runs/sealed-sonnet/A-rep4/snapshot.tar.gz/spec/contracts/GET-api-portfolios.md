# Contract: GET /api/portfolios

- **File:** src/app/api/portfolios/route.ts
- **Kind:** api
- **Line:** 13

## Signature (verbatim from source)

```
export async function GET(request: NextRequest) {
```
