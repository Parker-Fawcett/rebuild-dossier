# Contract: GET /api/seller

- **File:** src/app/api/seller/route.ts
- **Kind:** api
- **Line:** 10

## Signature (verbatim from source)

```
export async function GET(request: NextRequest) {
```
