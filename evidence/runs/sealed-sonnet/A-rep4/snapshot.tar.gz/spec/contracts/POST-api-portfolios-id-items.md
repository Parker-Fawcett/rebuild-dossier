# Contract: POST /api/portfolios/:id/items

- **File:** src/app/api/portfolios/[id]/items/route.ts
- **Kind:** api
- **Line:** 32

## Signature (verbatim from source)

```
export async function POST(request: NextRequest, { params }: { params: { id: string } }) {
```
