# Contract: GET /api/auth/google/callback

- **File:** src/app/api/auth/google/callback/route.ts
- **Kind:** api
- **Line:** 15

## Signature (verbatim from source)

```
export async function GET(request: NextRequest) {
```
