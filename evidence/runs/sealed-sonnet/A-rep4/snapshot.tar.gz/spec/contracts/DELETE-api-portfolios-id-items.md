# Contract: DELETE /api/portfolios/:id/items

- **File:** src/app/api/portfolios/[id]/items/route.ts
- **Kind:** api
- **Line:** 69

## Signature (verbatim from source)

```
export async function DELETE(request: NextRequest, { params }: { params: { id: string; itemId: string } }) {
```
