# Contract: /collection/pokedex/:id

- **File:** src/app/collection/pokedex/[id]/page.tsx
- **Kind:** page
- **Line:** 60

## Signature (verbatim from source)

```
export default function PokemonDetailPage() {
```
