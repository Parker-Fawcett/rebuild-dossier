# Contract: PUT /api/portfolios/:id

- **File:** src/app/api/portfolios/[id]/route.ts
- **Kind:** api
- **Line:** 30

## Signature (verbatim from source)

```
export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
```
