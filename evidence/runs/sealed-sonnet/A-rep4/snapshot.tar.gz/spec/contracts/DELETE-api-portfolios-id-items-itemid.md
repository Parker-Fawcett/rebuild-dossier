# Contract: DELETE /api/portfolios/:id/items/:itemId

- **File:** src/app/api/portfolios/[id]/items/[itemId]/route.ts
- **Kind:** api
- **Line:** 65

## Signature (verbatim from source)

```
export async function DELETE(request: NextRequest, { params }: { params: { id: string; itemId: string } }) {
```
