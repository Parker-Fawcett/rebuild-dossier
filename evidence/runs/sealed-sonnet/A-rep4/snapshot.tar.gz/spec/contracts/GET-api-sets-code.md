# Contract: GET /api/sets/:code

- **File:** src/app/api/sets/[code]/route.ts
- **Kind:** api
- **Line:** 4

## Signature (verbatim from source)

```
export async function GET(request: NextRequest, { params }: { params: { code: string } }) {
```
