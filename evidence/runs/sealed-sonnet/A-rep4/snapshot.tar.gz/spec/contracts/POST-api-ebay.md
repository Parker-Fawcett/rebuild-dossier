# Contract: POST /api/ebay

- **File:** src/app/api/ebay/route.ts
- **Kind:** api
- **Line:** 82

## Signature (verbatim from source)

```
export async function POST(request: NextRequest) {
```
