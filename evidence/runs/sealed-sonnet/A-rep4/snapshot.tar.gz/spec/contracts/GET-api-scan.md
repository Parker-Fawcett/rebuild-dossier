# Contract: GET /api/scan

- **File:** src/app/api/scan/route.ts
- **Kind:** api
- **Line:** 7

## Signature (verbatim from source)

```
export async function GET() {
```
