# Contract: GET /api/cards

- **File:** src/app/api/cards/route.ts
- **Kind:** api
- **Line:** 7

## Signature (verbatim from source)

```
export async function GET(request: NextRequest) {
```
