# Contract: GET /api/sets

- **File:** src/app/api/sets/route.ts
- **Kind:** api
- **Line:** 6

## Signature (verbatim from source)

```
export async function GET() {
```
