# Contract: GET /api/users

- **File:** src/app/api/users/route.ts
- **Kind:** api
- **Line:** 6

## Signature (verbatim from source)

```
export async function GET(request: NextRequest) {
```
