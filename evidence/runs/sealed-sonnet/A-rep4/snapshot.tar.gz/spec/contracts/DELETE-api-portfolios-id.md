# Contract: DELETE /api/portfolios/:id

- **File:** src/app/api/portfolios/[id]/route.ts
- **Kind:** api
- **Line:** 54

## Signature (verbatim from source)

```
export async function DELETE(request: NextRequest, { params }: { params: { id: string } }) {
```
