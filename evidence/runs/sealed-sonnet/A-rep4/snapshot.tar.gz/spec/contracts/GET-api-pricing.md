# Contract: GET /api/pricing

- **File:** src/app/api/pricing/route.ts
- **Kind:** api
- **Line:** 7

## Signature (verbatim from source)

```
export async function GET(request: NextRequest) {
```
