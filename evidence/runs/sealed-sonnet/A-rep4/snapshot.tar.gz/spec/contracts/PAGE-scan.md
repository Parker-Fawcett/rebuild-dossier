# Contract: /scan

- **File:** src/app/scan/page.tsx
- **Kind:** page
- **Line:** 5

## Signature (verbatim from source)

```
export default function ScanPage() {
```
