# Contract: GET /api/cards/:id

- **File:** src/app/api/cards/[id]/route.ts
- **Kind:** api
- **Line:** 28

## Signature (verbatim from source)

```
export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
```
