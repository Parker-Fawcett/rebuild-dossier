# Contract: /portfolio

- **File:** src/app/portfolio/page.tsx
- **Kind:** page
- **Line:** 51

## Signature (verbatim from source)

```
export default function PortfolioPage() {
```
