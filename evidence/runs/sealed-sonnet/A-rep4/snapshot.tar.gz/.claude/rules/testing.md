# Testing conventions

- Run `npm test` to check the visible suite. A PostToolUse hook
  already runs it after every edit — this is for manual checks.
- Work test-by-test: pick one failing test, make the smallest change
  that could pass it, then re-run the FULL tests/visible/ suite before
  moving to the next.
- Held-out acceptance tests exist to catch tests gamed against
  tests/visible/. The evaluator holds them outside this workspace and
  runs them once, after you finish.
- A test flagged "weak" (in tests/weak/, if present) failed a mutation
  check during generation: it didn't catch a deliberately introduced
  bug in the original code. Treat it as informational, not a target.
