export const meta = {
  name: 'parallel-test-fix',
  description:
    'Fix this project\'s currently-failing tests/visible/ tests, clustered by shared source files (precomputed from spec/test-dependencies.json at generation time), each cluster in its own isolated worktree, then merge and re-run the full suite once to catch cross-cluster regressions.',
  phases: [{ title: 'Check status' }, { title: 'Fix' }, { title: 'Merge & verify' }]
}

// This project's actual test/file clusters, computed once at generate_spec
// time from spec/test-dependencies.json — not rediscovered here, so there's
// no extra LLM round-trip that could get the clustering wrong.
const clusters = [
  {
    "tests": [
      "POST-api-auth.spec.ts"
    ],
    "files": [
      "src/app/api/auth/route.ts"
    ]
  },
  {
    "tests": [
      "POST-api-ebay.spec.ts"
    ],
    "files": [
      "src/app/api/ebay/route.ts"
    ]
  },
  {
    "tests": [
      "PUT-api-listings-id.spec.ts"
    ],
    "files": [
      "src/app/api/listings/[id]/route.ts"
    ]
  },
  {
    "tests": [
      "POST-api-orders.spec.ts",
      "PUT-api-orders.spec.ts"
    ],
    "files": [
      "src/app/api/orders/route.ts"
    ]
  },
  {
    "tests": [
      "GET-api-pokedex.spec.ts"
    ],
    "files": [
      "src/app/api/pokedex/route.ts"
    ]
  },
  {
    "tests": [
      "GET-api-portfolios-id-items-itemid.spec.ts",
      "DELETE-api-portfolios-id-items-itemid.spec.ts"
    ],
    "files": [
      "src/app/api/portfolios/[id]/items/[itemId]/route.ts"
    ]
  },
  {
    "tests": [
      "GET-api-portfolios-id-items.spec.ts",
      "DELETE-api-portfolios-id-items.spec.ts"
    ],
    "files": [
      "src/app/api/portfolios/[id]/items/route.ts"
    ]
  },
  {
    "tests": [
      "GET-api-portfolios-id.spec.ts",
      "DELETE-api-portfolios-id.spec.ts"
    ],
    "files": [
      "src/app/api/portfolios/[id]/route.ts"
    ]
  },
  {
    "tests": [
      "GET-api-portfolios-id-value.spec.ts"
    ],
    "files": [
      "src/app/api/portfolios/[id]/value/route.ts"
    ]
  },
  {
    "tests": [
      "POST-api-portfolios.spec.ts"
    ],
    "files": [
      "src/app/api/portfolios/route.ts"
    ]
  },
  {
    "tests": [
      "POST-api-pricing.spec.ts"
    ],
    "files": [
      "src/app/api/pricing/route.ts"
    ]
  },
  {
    "tests": [
      "PUT-api-seller.spec.ts"
    ],
    "files": [
      "src/app/api/seller/route.ts"
    ]
  },
  {
    "tests": [
      "GET-api-users-me.spec.ts"
    ],
    "files": [
      "src/app/api/users/me/route.ts"
    ]
  },
  {
    "tests": [
      "PUT-api-users-profile.spec.ts"
    ],
    "files": [
      "src/app/api/users/profile/route.ts"
    ]
  },
  {
    "tests": [
      "GET-api-watchlist.spec.ts"
    ],
    "files": [
      "src/app/api/watchlist/route.ts"
    ]
  },
  {
    "tests": [
      "GET-api-wishlist.spec.ts"
    ],
    "files": [
      "src/app/api/wishlist/route.ts"
    ]
  }
]

phase('Check status')
await agent(
  'If this directory is not yet a git repository, run "git init" and commit the current state. Report done.',
  { phase: 'Check status' }
)
const allTests = clusters.flatMap((c) => c.tests)
const status = await agent(
  `Run the full tests/visible/ suite. Report which of these specific tests are currently failing: ${allTests.join(', ')}.`,
  {
    phase: 'Check status',
    schema: { type: 'object', required: ['failingTests'], properties: { failingTests: { type: 'array', items: { type: 'string' } } } }
  }
)

const failingClusters = clusters
  .map((c) => ({ ...c, tests: c.tests.filter((t) => status.failingTests.includes(t)) }))
  .filter((c) => c.tests.length > 0)

if (failingClusters.length === 0) {
  log('All tests in tests/visible/ are already passing — nothing to fix.')
} else if (failingClusters.length === 1) {
  log('Only one cluster has failing tests right now — nothing to parallelize; fix it directly rather than through this workflow.')
} else {
  phase('Fix')
  await parallel(
    failingClusters.map((cluster, i) => () =>
      agent(
        `Work ONLY on these currently-failing tests: ${cluster.tests.join(', ')}. You may only touch these files: ${cluster.files.join(', ')}. Fix one test at a time, smallest possible change, re-running this cluster's own tests after each fix before moving to the next. Do not touch any file outside this list — another agent may be editing a different cluster concurrently in its own worktree.`,
        { label: `cluster-${i}`, phase: 'Fix', isolation: 'worktree' }
      )
    )
  )

  phase('Merge & verify')
  const finalReport = await agent(
    "Merge all worktree branches from the parallel fix phase back into the main branch, resolving any conflicts. Then run the FULL tests/visible/ suite once — not just each cluster's own tests, to catch cross-cluster regressions the isolated subagents could not see. If anything is now failing that wasn't part of any cluster's assignment, that's a regression: fix it with a single serial change, not another parallel wave, since diagnosing a cross-file regression needs the shared state parallel isolation throws away. Report final tests/visible/ pass/fail counts. Do NOT run tests/held-out/ — that happens once, manually, only after every visible test passes.",
    { phase: 'Merge & verify' }
  )
  log(finalReport)
}

return { clusters, failingClusters }
