// North Mini Code model verification
## Model Comparison

Based on web search results, North Mini Code is a Cohere model, not a OpenCode variant.

### North Mini Code (Cohere)**:
- Model: Cohere North Mini Code (MoE 30B with 3B active)
- License: Apache 2.0
- Family: Cohere models
- Context: 256K tokens
- Available via Cohere API
- Not a OpenCode model

### DeepSeek V4 Flash (OpenCode)**:
- Model: opencode/deepseek-v4-flash-free (current entry in MODELS.md)
- Provider: OpenCode Zen
- License: Proprietary API
- Family: deepseek-flash
- Context: 1.0M tokens
- Available via OpenCode API (Free tier)

### Conclusion:
North Mini Code and DeepSeek V4 Flash are different models from different providers.
The current MODELS.md entry refers to opencode/deepseek-v4-flash-free.
Adding North Mini Code would require a new entry, not modifying the existing one.

To add North Mini Code to MODELS.md, it would need:
1. Be a OpenCode model (available via opencode models command)
2. Have verified metadata from opencode models opencode --verbose
3. Be appropriate for this ablation
