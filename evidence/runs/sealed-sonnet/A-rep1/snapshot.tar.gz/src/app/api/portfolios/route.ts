import { NextRequest, NextResponse } from 'next/server';
import { portfolios, createId } from '../../../lib/store';

export async function POST(request: NextRequest) {
  let body: any = {};
  try {
    body = await request.json();
  } catch {
    body = {};
  }

  const { name, userId } = body ?? {};

  const portfolio = {
    id: createId(),
    userId: userId ?? null,
    name: name ?? 'My Portfolio',
    items: [],
    createdAt: new Date().toISOString(),
  };
  portfolios.set(portfolio.id, portfolio);

  return NextResponse.json(portfolio, { status: 201 });
}
