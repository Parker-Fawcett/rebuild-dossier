import { NextRequest, NextResponse } from 'next/server';
import { orders, createId } from '../../../lib/store';

export async function POST(request: NextRequest) {
  let body: any = {};
  try {
    body = await request.json();
  } catch {
    body = {};
  }

  const { listingId, quantity } = body ?? {};
  if (!listingId) {
    return NextResponse.json({ error: 'listingId is required' }, { status: 400 });
  }

  const order = {
    id: createId(),
    listingId,
    quantity: quantity ?? 1,
    status: 'pending',
    createdAt: new Date().toISOString(),
  };
  orders.set(order.id, order);

  return NextResponse.json(order, { status: 201 });
}

export async function PUT(request: NextRequest) {
  let body: any = {};
  try {
    body = await request.json();
  } catch {
    body = {};
  }

  const { id, status } = body ?? {};
  const order = id ? orders.get(id) : undefined;
  if (!order) {
    return NextResponse.json({ error: 'order not found' }, { status: 404 });
  }

  if (status) {
    order.status = status;
  }

  return NextResponse.json(order);
}
