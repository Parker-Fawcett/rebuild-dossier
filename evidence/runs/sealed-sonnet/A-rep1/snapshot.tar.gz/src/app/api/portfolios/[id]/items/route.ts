import { NextRequest, NextResponse } from 'next/server';
import { portfolios } from '../../../../../lib/store';

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  const portfolio = portfolios.get(params.id);
  if (!portfolio) {
    return NextResponse.json({ error: 'portfolio not found' }, { status: 404 });
  }
  return NextResponse.json(portfolio.items);
}

export async function DELETE(request: NextRequest, { params }: { params: { id: string; itemId: string } }) {
  const portfolio = portfolios.get(params.id);
  if (!portfolio) {
    return NextResponse.json({ error: 'portfolio not found' }, { status: 404 });
  }
  portfolio.items = [];
  return NextResponse.json({ success: true });
}
