import { NextRequest, NextResponse } from 'next/server';
import { portfolios } from '../../../../../lib/store';

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  const portfolio = portfolios.get(params.id);
  if (!portfolio) {
    return NextResponse.json({ error: 'portfolio not found' }, { status: 404 });
  }

  const totalValue = portfolio.items.reduce((sum, item) => sum + item.value * item.quantity, 0);

  return NextResponse.json({ portfolioId: portfolio.id, totalValue });
}
