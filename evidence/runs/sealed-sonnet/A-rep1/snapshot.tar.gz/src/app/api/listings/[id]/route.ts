import { NextRequest, NextResponse } from 'next/server';
import { listings } from '../../../../lib/store';

export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
  let body: any = {};
  try {
    body = await request.json();
  } catch {
    body = {};
  }

  const existing = listings.get(params.id);
  if (!existing) {
    return NextResponse.json({ error: 'listing not found' }, { status: 404 });
  }

  const updated = { ...existing, ...body, id: existing.id };
  listings.set(existing.id, updated);

  return NextResponse.json(updated);
}
