import { NextRequest, NextResponse } from 'next/server';

export async function POST(request: NextRequest) {
  let body: any = {};
  try {
    body = await request.json();
  } catch {
    body = {};
  }

  const { query } = body ?? {};
  if (!query) {
    return NextResponse.json({ error: 'query is required' }, { status: 400 });
  }

  return NextResponse.json({ query, results: [] });
}
