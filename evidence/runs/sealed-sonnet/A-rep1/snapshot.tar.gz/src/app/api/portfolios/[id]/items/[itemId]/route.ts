import { NextRequest, NextResponse } from 'next/server';
import { portfolios } from '../../../../../../lib/store';

export async function GET(request: NextRequest, { params }: { params: { id: string; itemId: string } }) {
  const portfolio = portfolios.get(params.id);
  if (!portfolio) {
    return NextResponse.json({ error: 'portfolio not found' }, { status: 404 });
  }

  const item = portfolio.items.find((i) => i.id === params.itemId);
  if (!item) {
    return NextResponse.json({ error: 'item not found' }, { status: 404 });
  }

  return NextResponse.json(item);
}

export async function DELETE(request: NextRequest, { params }: { params: { id: string; itemId: string } }) {
  const portfolio = portfolios.get(params.id);
  if (!portfolio) {
    return NextResponse.json({ error: 'portfolio not found' }, { status: 404 });
  }

  const index = portfolio.items.findIndex((i) => i.id === params.itemId);
  if (index === -1) {
    return NextResponse.json({ error: 'item not found' }, { status: 404 });
  }

  portfolio.items.splice(index, 1);
  return NextResponse.json({ success: true });
}
