// Minimal in-memory data layer shared across API routes. This workspace's
// spec/contracts only pin function signatures, not a database schema, so
// routes that need to persist something between requests share these maps
// instead of each inventing incompatible ad-hoc state.

let idCounter = 0;
export function createId(): string {
  idCounter += 1;
  return `id-${idCounter}`;
}

export type Portfolio = {
  id: string;
  userId: string | null;
  name: string;
  items: PortfolioItem[];
  createdAt: string;
};

export type PortfolioItem = {
  id: string;
  cardId: string;
  quantity: number;
  value: number;
};

export type Order = {
  id: string;
  listingId: string;
  quantity: number;
  status: string;
  createdAt: string;
};

export type Listing = {
  id: string;
  title: string;
  price: number;
  status: string;
};

export const portfolios = new Map<string, Portfolio>();
export const orders = new Map<string, Order>();
export const listings = new Map<string, Listing>();
