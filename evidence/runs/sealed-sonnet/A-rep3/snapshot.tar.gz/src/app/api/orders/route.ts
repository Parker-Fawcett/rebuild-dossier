import { NextRequest, NextResponse } from 'next/server';

export async function POST(request: NextRequest) {
  const token = request.cookies.get('session')?.value;
  if (!token) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  let body: Record<string, unknown>;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: 'Invalid JSON body' }, { status: 400 });
  }

  if (!body || typeof body.listingId !== 'string') {
    return NextResponse.json({ error: 'A listingId is required' }, { status: 400 });
  }

  return NextResponse.json({ ...body, buyerId: token }, { status: 201 });
}

export async function PUT(request: NextRequest) {
  const token = request.cookies.get('session')?.value;
  if (!token) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  let body: Record<string, unknown>;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: 'Invalid JSON body' }, { status: 400 });
  }

  if (!body || typeof body.id !== 'string') {
    return NextResponse.json({ error: 'An order id is required' }, { status: 400 });
  }

  return NextResponse.json({ error: 'Order not found' }, { status: 404 });
}
