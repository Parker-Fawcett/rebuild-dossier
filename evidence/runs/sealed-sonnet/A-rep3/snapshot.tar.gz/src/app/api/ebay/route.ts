import { NextRequest, NextResponse } from 'next/server';

export async function POST(request: NextRequest) {
  let body: Record<string, unknown>;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: 'Invalid JSON body' }, { status: 400 });
  }

  if (!body || typeof body.query !== 'string') {
    return NextResponse.json({ error: 'A search query is required' }, { status: 400 });
  }

  return NextResponse.json({ results: [] });
}
