import { NextRequest, NextResponse } from 'next/server';

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  if (!params.id) {
    return NextResponse.json({ error: 'Portfolio id is required' }, { status: 400 });
  }

  return NextResponse.json({ portfolioId: params.id, totalValue: 0 });
}
