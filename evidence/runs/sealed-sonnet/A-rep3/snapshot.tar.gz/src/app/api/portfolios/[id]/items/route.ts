import { NextRequest, NextResponse } from 'next/server';

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  if (!params.id) {
    return NextResponse.json({ error: 'Portfolio id is required' }, { status: 400 });
  }

  return NextResponse.json([]);
}

export async function DELETE(request: NextRequest, { params }: { params: { id: string; itemId: string } }) {
  const token = request.cookies.get('session')?.value;
  if (!token) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
  if (!params.id) {
    return NextResponse.json({ error: 'Portfolio id is required' }, { status: 400 });
  }

  return NextResponse.json({ error: 'Item not found' }, { status: 404 });
}
