import { NextRequest, NextResponse } from 'next/server';
import { getSessionUser } from '../../../lib/auth';

export async function PUT(request: NextRequest) {
  const session = await getSessionUser(request);
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  let body: Record<string, unknown>;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: 'Invalid JSON body' }, { status: 400 });
  }

  return NextResponse.json({ userId: session.userId, ...body });
}
