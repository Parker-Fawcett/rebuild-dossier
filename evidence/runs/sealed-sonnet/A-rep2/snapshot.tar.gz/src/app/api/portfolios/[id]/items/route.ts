import { NextRequest, NextResponse } from 'next/server';
import { getSessionUser } from '../../../../../lib/auth';
import { portfolios } from '../../../../../lib/store';

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  const session = await getSessionUser(request);
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  const portfolio = portfolios.find((p) => p.id === params.id);
  if (!portfolio) {
    return NextResponse.json({ error: 'Portfolio not found' }, { status: 404 });
  }
  if (portfolio.userId !== session.userId) {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
  }

  return NextResponse.json(portfolio.items);
}

export async function DELETE(request: NextRequest, { params }: { params: { id: string; itemId: string } }) {
  const session = await getSessionUser(request);
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  const portfolio = portfolios.find((p) => p.id === params.id);
  if (!portfolio) {
    return NextResponse.json({ error: 'Portfolio not found' }, { status: 404 });
  }
  if (portfolio.userId !== session.userId) {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
  }

  portfolio.items = [];
  return new NextResponse(null, { status: 204 });
}
