import { NextRequest, NextResponse } from 'next/server';
import { getSessionUser } from '../../../lib/auth';
import { portfolios } from '../../../lib/store';

export async function POST(request: NextRequest) {
  const session = await getSessionUser(request);
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  let body: Record<string, unknown>;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: 'Invalid JSON body' }, { status: 400 });
  }

  const { name } = body as { name?: string };
  if (!name) {
    return NextResponse.json({ error: 'name is required' }, { status: 400 });
  }

  const portfolio = { id: crypto.randomUUID(), userId: session.userId, name, items: [] };
  portfolios.push(portfolio);
  return NextResponse.json(portfolio, { status: 201 });
}
