import { NextRequest, NextResponse } from 'next/server';
import { getSessionUser } from '../../../../../../lib/auth';
import { portfolios } from '../../../../../../lib/store';

export async function GET(request: NextRequest, { params }: { params: { id: string; itemId: string } }) {
  const session = await getSessionUser(request);
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  const portfolio = portfolios.find((p) => p.id === params.id);
  if (!portfolio) {
    return NextResponse.json({ error: 'Portfolio not found' }, { status: 404 });
  }
  if (portfolio.userId !== session.userId) {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
  }

  const item = portfolio.items.find((i) => i.id === params.itemId);
  if (!item) {
    return NextResponse.json({ error: 'Item not found' }, { status: 404 });
  }

  return NextResponse.json(item);
}

export async function DELETE(request: NextRequest, { params }: { params: { id: string; itemId: string } }) {
  const session = await getSessionUser(request);
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  const portfolio = portfolios.find((p) => p.id === params.id);
  if (!portfolio) {
    return NextResponse.json({ error: 'Portfolio not found' }, { status: 404 });
  }
  if (portfolio.userId !== session.userId) {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
  }

  const index = portfolio.items.findIndex((i) => i.id === params.itemId);
  if (index === -1) {
    return NextResponse.json({ error: 'Item not found' }, { status: 404 });
  }

  portfolio.items.splice(index, 1);
  return new NextResponse(null, { status: 204 });
}
