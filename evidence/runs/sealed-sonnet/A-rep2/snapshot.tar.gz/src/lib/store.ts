export interface User {
  id: string;
  email: string;
  username: string;
  passwordHash: string;
}

export interface PortfolioItem {
  id: string;
  cardId: string;
  quantity: number;
  purchasePrice: number;
}

export interface Portfolio {
  id: string;
  userId: string;
  name: string;
  items: PortfolioItem[];
}

export interface Order {
  id: string;
  buyerId: string;
  listingId: string;
  status: string;
}

export interface Listing {
  id: string;
  sellerId: string;
  cardId: string;
  price: number;
  status: string;
}

export const users: User[] = [];
export const portfolios: Portfolio[] = [];
export const orders: Order[] = [];
export const listings: Listing[] = [];
