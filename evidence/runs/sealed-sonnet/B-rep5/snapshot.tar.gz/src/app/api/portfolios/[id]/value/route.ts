import { NextRequest, NextResponse } from 'next/server';
import { getSessionUserId } from '../../../../../lib/auth.js';
import { portfolios } from '../../../../../lib/store.js';

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  const userId = getSessionUserId(request);
  if (!userId) {
    return NextResponse.json({ error: 'Not authenticated' }, { status: 401 });
  }

  const portfolio = portfolios.get(params.id);
  if (!portfolio) {
    return NextResponse.json({ error: 'Portfolio not found' }, { status: 404 });
  }

  return NextResponse.json({ portfolioId: portfolio.id, totalValue: 0 });
}
