import { NextRequest, NextResponse } from 'next/server';
import { getSessionUserId } from '../../../lib/auth.js';
import { portfolios } from '../../../lib/store.js';

export async function POST(request: NextRequest) {
  const userId = getSessionUserId(request);
  if (!userId) {
    return NextResponse.json({ error: 'Not authenticated' }, { status: 401 });
  }

  let body: Record<string, unknown>;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: 'Invalid JSON body' }, { status: 400 });
  }

  const { name } = body as { name?: string };
  if (!name) {
    return NextResponse.json({ error: 'name is required' }, { status: 400 });
  }

  const portfolio = { id: crypto.randomUUID(), userId, name, items: [] };
  portfolios.set(portfolio.id, portfolio);

  return NextResponse.json(portfolio, { status: 201 });
}
