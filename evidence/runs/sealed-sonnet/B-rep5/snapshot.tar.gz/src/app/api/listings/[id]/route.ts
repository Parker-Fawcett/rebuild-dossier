import { NextRequest, NextResponse } from 'next/server';
import { getSessionUserId } from '../../../../lib/auth.js';
import { listings } from '../../../../lib/store.js';

export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
  const userId = getSessionUserId(request);
  if (!userId) {
    return NextResponse.json({ error: 'Not authenticated' }, { status: 401 });
  }

  const listing = listings.get(params.id);
  if (!listing) {
    return NextResponse.json({ error: 'Listing not found' }, { status: 404 });
  }

  let updates: Record<string, unknown>;
  try {
    updates = await request.json();
  } catch {
    return NextResponse.json({ error: 'Invalid JSON body' }, { status: 400 });
  }

  const updated = { ...listing, ...updates, id: listing.id };
  listings.set(listing.id, updated);

  return NextResponse.json(updated);
}
