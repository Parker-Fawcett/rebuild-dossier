import { NextRequest, NextResponse } from 'next/server';

export async function POST(request: NextRequest) {
  let body: Record<string, unknown>;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: 'Invalid JSON body' }, { status: 400 });
  }

  const { query } = body as { query?: string };
  if (!query) {
    return NextResponse.json({ error: 'query is required' }, { status: 400 });
  }

  return NextResponse.json({ results: [] });
}
