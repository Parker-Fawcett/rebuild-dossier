import { NextRequest, NextResponse } from 'next/server';
import { getSessionUserId } from '../../../../lib/auth.js';

export async function GET(request: NextRequest) {
  const userId = getSessionUserId(request);
  if (!userId) {
    return NextResponse.json({ error: 'Not authenticated' }, { status: 401 });
  }

  return NextResponse.json({ id: userId });
}
