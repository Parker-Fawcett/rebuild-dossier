export type PortfolioItem = {
  id: string;
  cardId: string;
  quantity: number;
};

export type Portfolio = {
  id: string;
  userId: string;
  name: string;
  items: PortfolioItem[];
};

export type Listing = {
  id: string;
  sellerId: string;
  price: number;
  status: string;
};

export const portfolios = new Map<string, Portfolio>();
export const listings = new Map<string, Listing>();
