import { NextRequest } from 'next/server';

export function getSessionUserId(request: NextRequest): string | null {
  return request.cookies.get('session')?.value ?? null;
}
