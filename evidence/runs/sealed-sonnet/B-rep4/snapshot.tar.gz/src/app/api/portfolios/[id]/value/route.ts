import { NextResponse, type NextRequest } from 'next/server';
import { db } from '../../../../../lib/store';

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  const portfolio = db.portfolios.find((p) => p.id === params.id);
  if (!portfolio) {
    return NextResponse.json({ error: 'Portfolio not found' }, { status: 404 });
  }
  const totalValue = portfolio.items.reduce(
    (sum, item) => sum + item.purchasePrice * item.quantity,
    0
  );
  return NextResponse.json({ portfolioId: portfolio.id, totalValue });
}
