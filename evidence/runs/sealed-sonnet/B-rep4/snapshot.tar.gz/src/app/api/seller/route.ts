import { NextResponse, type NextRequest } from 'next/server';
import { getSessionUser } from '../../../lib/auth';
import { db } from '../../../lib/store';

export async function PUT(request: NextRequest) {
  const user = await getSessionUser(request);
  if (!user) {
    return NextResponse.json({ error: 'Not authenticated' }, { status: 401 });
  }
  let body: any;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: 'Invalid JSON body' }, { status: 400 });
  }
  let seller = db.sellers.find((s) => s.userId === user.id);
  if (!seller) {
    seller = { userId: user.id, storeName: '' };
    db.sellers.push(seller);
  }
  if (typeof body?.storeName === 'string') seller.storeName = body.storeName;
  if (typeof body?.bio === 'string') seller.bio = body.bio;
  return NextResponse.json(seller);
}
