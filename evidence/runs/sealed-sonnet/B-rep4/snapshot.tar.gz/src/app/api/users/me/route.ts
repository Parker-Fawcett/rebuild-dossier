import { NextResponse, type NextRequest } from 'next/server';
import { getSessionUser } from '../../../../lib/auth';

export async function GET(request: NextRequest) {
  const user = await getSessionUser(request);
  if (!user) {
    return NextResponse.json({ error: 'Not authenticated' }, { status: 401 });
  }
  const { passwordHash, ...safeUser } = user;
  return NextResponse.json(safeUser);
}
