import { NextResponse, type NextRequest } from 'next/server';
import { db } from '../../../../lib/store';

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  const portfolio = db.portfolios.find((p) => p.id === params.id);
  if (!portfolio) {
    return NextResponse.json({ error: 'Portfolio not found' }, { status: 404 });
  }
  return NextResponse.json(portfolio);
}

export async function DELETE(request: NextRequest, { params }: { params: { id: string } }) {
  const index = db.portfolios.findIndex((p) => p.id === params.id);
  if (index === -1) {
    return NextResponse.json({ error: 'Portfolio not found' }, { status: 404 });
  }
  const [removed] = db.portfolios.splice(index, 1);
  return NextResponse.json(removed);
}
