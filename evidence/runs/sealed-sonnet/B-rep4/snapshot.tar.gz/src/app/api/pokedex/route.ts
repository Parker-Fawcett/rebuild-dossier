import { NextResponse, type NextRequest } from 'next/server';
import { db } from '../../../lib/store';

export async function GET(request: NextRequest) {
  return NextResponse.json(db.pokedex);
}
