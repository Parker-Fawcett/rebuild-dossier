import { NextResponse, type NextRequest } from 'next/server';
import { db } from '../../../lib/store';

export async function POST(request: NextRequest) {
  let body: any;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: 'Invalid JSON body' }, { status: 400 });
  }
  const { cardId, grade } = body ?? {};
  if (!cardId) {
    return NextResponse.json({ error: 'cardId is required' }, { status: 400 });
  }
  const card = db.pokedex.find((c) => c.id === cardId);
  const basePrice = card?.basePrice ?? 0;
  const multiplier = typeof grade === 'number' ? 1 + grade / 10 : 1;
  return NextResponse.json({
    cardId,
    grade: grade ?? null,
    price: Math.round(basePrice * multiplier * 100) / 100,
  });
}
