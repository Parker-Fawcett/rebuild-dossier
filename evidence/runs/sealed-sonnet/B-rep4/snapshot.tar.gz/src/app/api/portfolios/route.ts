import { NextResponse, type NextRequest } from 'next/server';
import { randomUUID } from 'crypto';
import { db, type Portfolio } from '../../../lib/store';

export async function POST(request: NextRequest) {
  let body: any;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: 'Invalid JSON body' }, { status: 400 });
  }
  const { userId, name } = body ?? {};
  if (!userId || !name) {
    return NextResponse.json({ error: 'userId and name are required' }, { status: 400 });
  }
  const portfolio: Portfolio = { id: randomUUID(), userId, name, items: [] };
  db.portfolios.push(portfolio);
  return NextResponse.json(portfolio, { status: 201 });
}
