import { NextResponse, type NextRequest } from 'next/server';
import { db } from '../../../../../../lib/store';

export async function GET(request: NextRequest, { params }: { params: { id: string; itemId: string } }) {
  const portfolio = db.portfolios.find((p) => p.id === params.id);
  if (!portfolio) {
    return NextResponse.json({ error: 'Portfolio not found' }, { status: 404 });
  }
  const item = portfolio.items.find((i) => i.id === params.itemId);
  if (!item) {
    return NextResponse.json({ error: 'Item not found' }, { status: 404 });
  }
  return NextResponse.json(item);
}

export async function DELETE(request: NextRequest, { params }: { params: { id: string; itemId: string } }) {
  const portfolio = db.portfolios.find((p) => p.id === params.id);
  if (!portfolio) {
    return NextResponse.json({ error: 'Portfolio not found' }, { status: 404 });
  }
  const index = portfolio.items.findIndex((i) => i.id === params.itemId);
  if (index === -1) {
    return NextResponse.json({ error: 'Item not found' }, { status: 404 });
  }
  const [removed] = portfolio.items.splice(index, 1);
  return NextResponse.json(removed);
}
