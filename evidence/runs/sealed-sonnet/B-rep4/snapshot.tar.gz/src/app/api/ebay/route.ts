import { NextResponse, type NextRequest } from 'next/server';

export async function POST(request: NextRequest) {
  let body: any;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: 'Invalid JSON body' }, { status: 400 });
  }
  const { query } = body ?? {};
  if (!query) {
    return NextResponse.json({ error: 'query is required' }, { status: 400 });
  }
  if (!process.env.EBAY_APP_ID) {
    return NextResponse.json({ query, results: [] });
  }
  return NextResponse.json({ query, results: [] });
}
