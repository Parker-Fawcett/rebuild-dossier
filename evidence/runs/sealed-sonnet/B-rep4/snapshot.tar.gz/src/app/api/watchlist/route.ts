import { NextResponse, type NextRequest } from 'next/server';
import { getSessionUser } from '../../../lib/auth';
import { db } from '../../../lib/store';

export async function GET(request: NextRequest) {
  const user = await getSessionUser(request);
  if (!user) return NextResponse.json([]);
  return NextResponse.json(db.watchlist.filter((w) => w.userId === user.id));
}
