import { NextResponse, type NextRequest } from 'next/server';
import { getSessionUser } from '../../../../lib/auth';

export async function PUT(request: NextRequest) {
  const user = await getSessionUser(request);
  if (!user) {
    return NextResponse.json({ error: 'Not authenticated' }, { status: 401 });
  }
  let body: any;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: 'Invalid JSON body' }, { status: 400 });
  }
  if (typeof body?.displayName === 'string') user.displayName = body.displayName;
  if (typeof body?.bio === 'string') user.bio = body.bio;
  const { passwordHash, ...safeUser } = user;
  return NextResponse.json(safeUser);
}
