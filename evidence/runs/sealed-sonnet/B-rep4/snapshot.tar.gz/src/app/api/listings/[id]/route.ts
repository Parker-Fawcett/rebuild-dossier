import { NextResponse, type NextRequest } from 'next/server';
import { db } from '../../../../lib/store';

export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
  const listing = db.listings.find((l) => l.id === params.id);
  if (!listing) {
    return NextResponse.json({ error: 'Listing not found' }, { status: 404 });
  }
  let body: any;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: 'Invalid JSON body' }, { status: 400 });
  }
  if (typeof body?.price === 'number') listing.price = body.price;
  if (typeof body?.status === 'string') listing.status = body.status;
  return NextResponse.json(listing);
}
