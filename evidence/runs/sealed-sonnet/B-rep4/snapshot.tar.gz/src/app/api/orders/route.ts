import { NextResponse, type NextRequest } from 'next/server';
import { randomUUID } from 'crypto';
import { db, type Order } from '../../../lib/store';

export async function POST(request: NextRequest) {
  let body: any;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: 'Invalid JSON body' }, { status: 400 });
  }
  const { listingId, buyerId } = body ?? {};
  if (!listingId || !buyerId) {
    return NextResponse.json({ error: 'listingId and buyerId are required' }, { status: 400 });
  }
  const listing = db.listings.find((l) => l.id === listingId);
  if (!listing) {
    return NextResponse.json({ error: 'Listing not found' }, { status: 404 });
  }
  const order: Order = { id: randomUUID(), listingId, buyerId, status: 'pending' };
  db.orders.push(order);
  return NextResponse.json(order, { status: 201 });
}

export async function PUT(request: NextRequest) {
  let body: any;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: 'Invalid JSON body' }, { status: 400 });
  }
  const { id, status } = body ?? {};
  if (!id) {
    return NextResponse.json({ error: 'id is required' }, { status: 400 });
  }
  const order = db.orders.find((o) => o.id === id);
  if (!order) {
    return NextResponse.json({ error: 'Order not found' }, { status: 404 });
  }
  if (typeof status === 'string') order.status = status as Order['status'];
  return NextResponse.json(order);
}
