import { NextResponse, type NextRequest } from 'next/server';
import { db } from '../../../../../lib/store';

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  const portfolio = db.portfolios.find((p) => p.id === params.id);
  if (!portfolio) {
    return NextResponse.json({ error: 'Portfolio not found' }, { status: 404 });
  }
  return NextResponse.json(portfolio.items);
}

export async function DELETE(request: NextRequest, { params }: { params: { id: string; itemId: string } }) {
  const portfolio = db.portfolios.find((p) => p.id === params.id);
  if (!portfolio) {
    return NextResponse.json({ error: 'Portfolio not found' }, { status: 404 });
  }
  portfolio.items = [];
  return NextResponse.json(portfolio);
}
