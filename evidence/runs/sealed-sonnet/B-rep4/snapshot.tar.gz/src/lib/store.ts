export type User = {
  id: string;
  username: string;
  email: string;
  passwordHash: string;
  displayName?: string;
  bio?: string;
};

export type PortfolioItem = {
  id: string;
  cardId: string;
  quantity: number;
  purchasePrice: number;
};

export type Portfolio = {
  id: string;
  userId: string;
  name: string;
  items: PortfolioItem[];
};

export type Listing = {
  id: string;
  sellerId: string;
  cardId: string;
  price: number;
  status: 'active' | 'sold' | 'removed';
};

export type Order = {
  id: string;
  listingId: string;
  buyerId: string;
  status: 'pending' | 'paid' | 'shipped' | 'completed' | 'cancelled';
};

export type PokedexEntry = {
  id: string;
  name: string;
  setCode: string;
  basePrice: number;
};

export type WatchlistEntry = {
  id: string;
  userId: string;
  cardId: string;
};

export type Seller = {
  userId: string;
  storeName: string;
  bio?: string;
};

export const db = {
  users: [] as User[],
  portfolios: [] as Portfolio[],
  listings: [] as Listing[],
  orders: [] as Order[],
  pokedex: [] as PokedexEntry[],
  watchlist: [] as WatchlistEntry[],
  sellers: [] as Seller[],
};
