import { SignJWT, jwtVerify } from 'jose';
import type { NextRequest } from 'next/server';
import { db, type User } from './store';

const secret = new TextEncoder().encode(
  process.env.AUTH_SECRET || 'dev-secret-do-not-use-in-production'
);

export async function createSessionToken(userId: string): Promise<string> {
  return new SignJWT({ sub: userId })
    .setProtectedHeader({ alg: 'HS256' })
    .setIssuedAt()
    .setExpirationTime('7d')
    .sign(secret);
}

export async function getSessionUser(request: NextRequest): Promise<User | null> {
  const token = request.cookies.get('session')?.value;
  if (!token) return null;
  try {
    const { payload } = await jwtVerify(token, secret);
    const userId = payload.sub;
    return db.users.find((u) => u.id === userId) ?? null;
  } catch {
    return null;
  }
}
